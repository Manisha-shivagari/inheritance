package com.cg.inheritance.beans;
public abstract class Employee {
private int  employeeId , basicSalary;
private float totalSalary;
private String firstName,lastName;
public Employee(){
	super();
}
public Employee(int employeeId, String firstName, String lastName,int basicSalary) {
	super();
	this.employeeId = employeeId;
	this.basicSalary=basicSalary;
	this.firstName = firstName;
	this.lastName = lastName;
}

public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public int getBasicSalary() {
	return basicSalary;
}
public void setBasicSalary(int basicSalary) {
	this.basicSalary = basicSalary;
}
public float getTotalSalary() {
	return totalSalary;
}
public void setTotalSalary(float totalSalary) {
	this.totalSalary = totalSalary;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
	
}
public abstract void calculateSalary();
	//this.totalSalary=basicSalary;
	

@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ",totalSalary=" + totalSalary + ", firstName=" + firstName
			+ ", lastName=" + lastName + " ,";
}


}

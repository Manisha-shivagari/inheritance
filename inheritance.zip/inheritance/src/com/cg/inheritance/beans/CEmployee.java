package com.cg.inheritance.beans;
public final class CEmployee extends Employee{
	private float hrs,variablePay;

	public CEmployee() {
		super();
	}
	public CEmployee(int employeeId,String firstName,String lastName,float hrs,int basicSalary){
		super( employeeId,  firstName,lastName,basicSalary);
		this.hrs=hrs;
	}
	public CEmployee(int employeeId,String firstName,String lastName,float hrs, float variablePay,int basicSalary) {
		super(employeeId,firstName,lastName,basicSalary);
		this.hrs = hrs;
		this.variablePay = variablePay;
	}

	public float getHrs() {
		return hrs;
	}
	public void setHrs(float hrs) {
		this.hrs = hrs;
	}
	public float getVariablePay() {
		return variablePay;
	}
	public void setVariablePay(float variablePay) {
		this.variablePay = variablePay;
	}
	public void calculateSalary(){
		this.variablePay=hrs*2000;
		this.setTotalSalary(this.getBasicSalary()+variablePay);

	}
	public void signContract(){
		System.out.println("signed");
	}
	@Override
	public String toString() {
		return super.toString()+  "totalSalary=" +this.getTotalSalary() + "hrs=" + hrs + ", variablePay=" + variablePay + "]";
	}
}





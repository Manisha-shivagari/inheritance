package com.cg.inheritance.beans;

public final class SalesManager extends PEmployee {
private  int commission,salesAmount;
		public SalesManager() {
			super();
			}
		public SalesManager(int employeeId, int basicSalary, String firstName, String lastName,int salesAmount) {
			super(employeeId, firstName, lastName, basicSalary);
			this.salesAmount=salesAmount;
				}
		public SalesManager(int employeeId, int basicSalary, String firstName, String lastName,int commission, int salesAmount) {
			super(employeeId, firstName, lastName, basicSalary);
			this.commission = commission;
			this.salesAmount = salesAmount;
		
		}

		public int getCommission() {
			return commission;
		}

		public void setCommission(int commission) {
			this.commission = commission;
		}

		public int getSalesAmount() {
			return salesAmount;
		}

		public void setSalesAmount(int salesAmount) {
			this.salesAmount = salesAmount;
		}
	public void calculateSalary(){
		super.calculateSalary();
		this.commission=salesAmount*10/100;
		 this.setTotalSalary(super.getBasicSalary()+	this.commission);
			
	}

	@Override
	public String toString() {
		return super.toString()+"commission  ="+ commission+", salesAmount=" + salesAmount ;
	}
		
	}


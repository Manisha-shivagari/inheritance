package com.cg.inheritance.beans;

public final class Developer extends PEmployee{
	private  int incentives;
			public Developer() {
				super();
				}
			public Developer(int employeeId,String firstName, String lastName,  int basicSalary,int incentives) {
				super(employeeId, firstName, lastName ,basicSalary);
				this.incentives = incentives;
			
					}
			public Developer(int employeeId, String firstName, String lastName, int basicSalary) {
				super(employeeId, firstName, lastName,basicSalary);
								
			
			}

		
		public Developer(int incentives) {
				super();
				this.incentives = incentives;
			}
		public void calculateSalary(){
			super.calculateSalary();
			 this.setTotalSalary(super.getBasicSalary()+this.incentives	);
				
			}
		public void doProject(){
			System.out.println("done");
		}

		@Override
		public String toString() {
			return super.toString()+ "incentives  ="+ incentives ;
		}
			
		}




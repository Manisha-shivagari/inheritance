package com.cg.inheritance.main;

import com.cg.inheritance.beans.CEmployee;
import com.cg.inheritance.beans.Developer;
import com.cg.inheritance.beans.Employee;
import com.cg.inheritance.beans.PEmployee;
import com.cg.inheritance.beans.SalesManager;

public class MainClass {

	public static void main(String[] args) {
	
	//Employee employee=new Employee(123,"mani","reddy",120000);
  //  employee.calculateSalary();
	//System.out.println(employee.toString());
	

	/*PEmployee pemployee=new PEmployee(1234,"mani","reddy",12090);
	pemployee.calculateSalary();
	System.out.println(pemployee.toString());
	

	SalesManager s=new SalesManager(123, 12000, "mani", "sha", 34000);
	s.calculateSalary();
	System.out.println(s.toString());
			
			CEmployee cemployee=new CEmployee(1234, "mani", "reddy", 10,1200);
			cemployee.calculateSalary();
			cemployee.signContract();
			System.out.println(cemployee.toString());
		*/	
			
			Employee employee;
			employee=new Developer(123,"mani","reddy",1200,10000);
			employee.calculateSalary();
			Developer developer=(Developer)employee;
			developer.doProject();
			System.out.println(employee.toString());
		
			
			
	}
}
